import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class HardcodedAuthenticationService {

  constructor() { }


  authenticate(username, password){

   // console.log('before' + this.isUserLoggedIn());
    if(username==="username" && password==="password"){
      sessionStorage.setItem('authenicaterUser', username);
      //console.log('after' + this.isUserLoggedIn());
      return true;
    }
    else{
      return false;
    }
  }

  isUserLoggedIn(){
    let user = sessionStorage.getItem('authenicaterUser');
    return !(user === null);
  }
}
